# Elgg Showcase
This plugin provides you with a way to let your community show off their design work.

Right now it is hard-coded with some sites that have been created with Elgg so
we can run it on Elgg Community. Eventually, though, we hope to add dynamic
features so that it can be more community-managed.