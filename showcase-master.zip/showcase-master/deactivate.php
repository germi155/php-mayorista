<?php

update_subtype('object', 'showcase', '');
update_subtype('object', 'showcaseimg', '');
