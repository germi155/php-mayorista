<?php

$vars['entity'] = new ElggShowcase();

echo elgg_view('forms/showcase/edit', $vars);
